# Style Guide — Motore di generazione capitoli
### Estratta dall'analisi del POC (guida Australia, 174 pp., ~44.000 parole)

Questo documento è operativo: entra nel contesto fisso (in prompt cache) di ogni chiamata di generazione. Ogni regola qui deriva da un pattern osservato nel testo gold copy, non da preferenze astratte.

---

## 1. La voce

**Registro:** narrativa colta ma piana. Frasi ritmate, alternanza di periodi brevi e ampi. Lessico ricco senza sfoggio. Mai tono da brochure, mai entusiasmo da marketing ("imperdibile!", "magico!"), mai elenchi camuffati da prosa.

**Persona:** seconda plurale rivolta ai viaggiatori ("dove alloggerete per quattro notti", "il vostro primo impatto"). I riferimenti alla loro logistica reale (hotel, date, voli) sono intrecciati NEL racconto, mai in un box a parte: l'hotel del cliente diventa un pretesto narrativo ("L'hotel W Sydney, dove alloggerete, sorge su Darling Harbour, una zona che fino agli anni Ottanta era un porto industriale puzzolente di pesce e diesel").

**Figura dell'autore:** un accompagnatore esperto e onesto, che ha opinioni e le motiva. Dice cosa NON fare e perché ("il viaggiatore intelligente sa che la passeggiata pedonale offre il novanta per cento dell'emozione a costo zero"). Mai neutro fino all'inutilità: la raccomandazione netta con motivazione è parte del valore.

## 2. Le mosse retoriche ricorrenti (il DNA)

1. **Attacco in medias res con una tesi**, mai con informazioni di servizio. "Ci sono luoghi che la fotografia ha consumato prima ancora che li si veda." / "C'è un numero, in questa guida, che bisogna imparare a maneggiare prima di ogni altro."
2. **I numeri si rendono tangibili con comparazioni**: 348 metri = "più della Torre Eiffel"; 60.000 anni = "quando i primi umani arrivarono, mancavano 40.000 anni a Lascaux". Un numero senza corpo è un numero sprecato.
3. **Doppio strato ovunque**: ogni luogo ha la storia visibile e quella sotto (la Sydney coloniale sopra la Sydney Gadigal; Darling Harbour elegante sopra il porto "puzzolente di pesce e diesel"). Il capitolo insegna a vedere entrambi.
4. **Il dettaglio-aneddoto che nessun'altra guida ha**: l'inaugurazione del ponte interrotta dal fascista a cavallo; i sedici operai morti incisi su una targa "raramente visitata". Uno-due per capitolo, scelti perché rivelano qualcosa di più grande.
5. **Prima il senso, poi la pratica.** La sezione pratica (come visitare, orari, costi) arriva sempre DOPO che il lettore sa perché il luogo conta. Mai il contrario.
6. **Collegamenti interni**: "quel sistema di cui abbiamo parlato nel primo capitolo". → Il motore deve ricevere l'outline completo della guida e i temi già introdotti.
7. **Chiusure di sezione con un'immagine o un'inversione**, non con un riassunto: "A metà strada ci si dimentica di essere turisti." / "Lo trasforma in ascolto."

## 3. Struttura del capitolo

- **Titolo**: nome del luogo (con nome indigeno dove esiste: "Sydney / Warrane") + sottotitolo evocativo che è una tesi ("La città che dimentica e ricorda").
- **Sezioni numerate romane** (I, II, III…) con titoli tematici brevi. 4-7 sezioni per capitolo di tappa.
- **Arco tipo del capitolo di tappa**: I. arrivo/impressione sensoriale → II. lo strato profondo (storia/cultura del luogo) → III-V. le esperienze, raccontate e poi rese pratiche → VI+. pratica pura (muoversi, mangiare, quartieri) — sempre ancorata alla logistica reale del cliente.
- **Lunghezza**: proporzionale a notti × densità della tappa. Nel POC: tappa principale (4 notti Sydney) ~7.000 parole; tappa da 1-2 notti ~2.500-3.500.

## 4. I box tematici (6 tipi, regole d'uso)

I box sono incastonati nel punto del testo dove sono pertinenti, mai raccolti a fine capitolo. 2-4 box per capitolo, mai due dello stesso tipo consecutivi. Lunghezza 80-150 parole. Ogni box ha titolo composto: `TIPO — titolo specifico e concreto`.

| Tipo | Funzione | Esempio dal POC |
|---|---|---|
| SLANG DEL GIORNO | Una parola/espressione locale, pronuncia, quando usarla | "Palya", la parola da portare a casa |
| STORIA PROFONDA | Approfondimento storico che il testo principale non regge | Myall Creek, l'eccezione che conferma la regola |
| BUSH TIP | Consiglio pratico operativo, con specifiche vere (litri, orari, senso di marcia) | Fare bene la Base Walk |
| SMART LUXURY | L'alternativa intelligente all'esperienza cara: stesso valore, meno soldi | Vedere l'Opera House senza fare il tour |
| ATTENZIONE | Cosa evitare o maneggiare con cura — anche esperienze famose, se il giudizio lo impone | Il BridgeClimb non si fa |
| A TAVOLA | Cibo come chiave culturale, non recensioni | Il Vegemite, e come non fare la figura del turista |

I nomi dei box sono adattabili alla destinazione (BUSH TIP ha senso in Australia; altrove diventa l'equivalente locale — es. TRAIL TIP, CITY TIP) ma i sei RUOLI restano fissi.

## 5. Onestà editoriale (regole non negoziabili)

- **Raccomandazioni motivate**, incluse quelle in negativo. Se un'esperienza famosa non vale il prezzo, dirlo, spiegando il calcolo.
- **Temi sensibili trattati con equilibrio adulto**: nel POC, colonizzazione, massacri, questioni aborigene sono raccontati senza sensazionalismo e senza omissione ("un'enorme storia di violenza, di lavoro, di reinvenzione"). Né agiografia né requisitoria.
- **Nomi indigeni/locali preferiti e spiegati** dove esistono, senza retorica.
- **Coerenza con la logistica del cliente**: se un evento/mercato/esperienza cade fuori dalle sue date, dirlo esplicitamente e offrire l'alternativa (pattern POC: mercato Mindil fuori date → segnalato + Parap il sabato).
- **Mai inventare specifiche.** Prezzi, orari, stati di apertura solo da ricerca fresca; se un dato non è verificabile, si scrive in modo che non serva ("verificate il calendario su [sito] prima della partenza" è il pattern approvato).

## 6. Cosa il motore deve ricevere per ogni capitolo (input contract)

1. Brief completo del viaggio (chi, occasione, stile, passioni, oro del colloquio)
2. Outline completo della guida + riassunto in 2 righe dei capitoli già scritti (per i collegamenti interni e per non ripetere)
3. Logistica reale della tappa: date esatte, notti, hotel, come si arriva/riparte
4. Risultati della ricerca fresca sulla tappa (aperture, chiusure, stagionalità nelle date del cliente)
5. Budget parole assegnato al capitolo

## 7. Anti-pattern (se compaiono, il capitolo è da rifare)

- Prosa-elenco: "Da vedere ci sono X, Y e Z. X è… Y è…"
- Superlativi vuoti e aggettivazione turistica ("suggestivo", "incantevole", "un'esperienza unica")
- Informazioni di servizio nell'attacco del capitolo
- Box generici che potrebbero stare in qualunque guida della stessa destinazione
- Dati specifici (prezzi, orari) non provenienti dalla ricerca del turno
- Ripetere al cliente informazioni che ha dato lui (elencargli il suo itinerario)
- Chiusure riassuntive ("Insomma, Sydney offre davvero tutto")
