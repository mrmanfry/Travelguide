# Engine v0 — Motore di generazione capitoli

Genera UN capitolo di guida personalizzata via API Anthropic (web search + prompt caching), lo salva in modo idempotente, cattura gli asset, e opzionalmente lo passa al critico di verifica.

## Setup

```bash
cd engine
python -m venv .venv && source .venv/bin/activate
pip install anthropic pydantic
export ANTHROPIC_API_KEY=sk-ant-...
```

Prima del primo run: verificare su https://platform.claude.com/docs gli id modello e la stringa versione del web search tool in `src/config.py` (le stringhe versionate cambiano nel tempo).

## Il test che conta

```bash
python -m src.run_chapter fixtures/lisbona.json --critic
```

Output in `output/fixture-lisbona-001/`: `cap_02.md` + `cap_02.usage.json` (token/costi) + `cap_02.critic.json` (alert di verifica).

**Criterio di accettazione:** confrontare `cap_02.md` con `reference/capitolo_gold_lisbona.md` (il capitolo validato, scritto con supervisione umana sullo stesso identico brief). Domande, in ordine:
1. Lo comprerei a 19,99€? (il criterio del fondatore)
2. Regge il confronto col gold su: attacco a tesi, doppio strato storico, personalizzazione intrecciata, giudizi netti motivati, box specifici?
3. I fatti freschi (chiusure, giorni dei mercati, coerenza con le date 18-21 set) ci sono?
4. Il critico ha prodotto alert sensati?

Le differenze in peggio rispetto al gold sono la todo-list dei prompt: ogni difetto ricorrente diventa una regola in `prompts/style_guide.md` o `prompts/chapter_system.md`. Iterare finché il criterio 1 è un sì senza esitazione, poi congelare la fixture come regression test.

## Struttura

```
schema/brief.py            contratto dati (Brief, ChapterAssignment) — Pydantic
prompts/style_guide.md     DNA editoriale estratto dal POC (in cache, condiviso da tutte le guide)
prompts/chapter_system.md  procedura di generazione + formato output + blocco META
prompts/critic_system.md   verifica: fatti (con search), logistica, stile, personalizzazione
src/chapter_runner.py      chiamata API, caching, salvataggio idempotente
src/run_chapter.py         CLI (+ critico)
src/assets.py              cattura asset su SQLite fin dalla v0 (riuso in v1)
src/config.py              leve di costo/qualità
fixtures/lisbona.json      brief fixture = regression test
reference/                 capitolo gold di confronto
```

## Principi non negoziabili (dal design concordato)

- **Una chiamata per capitolo**, mai conversazioni lunghe (costo lineare, non quadratico).
- **Prefisso in cache identico byte-per-byte** tra i capitoli della stessa guida (style guide + system + brief): qualunque modifica al prefisso invalida la cache.
- **Idempotenza**: un capitolo già su disco non si rigenera; un crash riparte da dove era.
- **Ricerca prima di scrivere, critico prima di consegnare**: nessun fatto specifico senza verifica del turno.
- **Cattura asset da subito, riuso solo quando aumenta il valore** (evergreen con rifinitura cumulativa; deperibile/personale sempre fresco).

## Roadmap engine (dopo che il test passa)

1. `run_guide.py`: orchestrazione multi-capitolo (outline → capitoli in sequenza → riassunti a cascata → critico su tutto).
2. Loop di correzione automatica: alert del critico → passaggio di fix mirato → ri-verifica.
3. Retrieve degli asset (evergreen, con freshness check + passaggio di personalizzazione) quando la libreria ha massa.
4. Produzione file: python-docx → PDF → copertina → CMYK, riusando le specifiche di stampa validate dal POC.
