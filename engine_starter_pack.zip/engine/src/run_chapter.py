"""CLI — genera un capitolo dalla fixture e (opzionale) lo passa al critico.

Uso:
    python -m src.run_chapter fixtures/lisbona.json            # genera
    python -m src.run_chapter fixtures/lisbona.json --critic   # genera + verifica
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import anthropic

from schema.brief import Brief, ChapterAssignment
from src import config
from src.chapter_runner import run_chapter, _load


def run_critic(brief: Brief, chapter_path: Path) -> Path:
    client = anthropic.Anthropic()
    system = [
        {"type": "text",
         "text": _load("style_guide.md") + "\n\n---\n\n" + _load("critic_system.md"),
         "cache_control": {"type": "ephemeral"}},
        {"type": "text",
         "text": "# BRIEF\n\n" + brief.model_dump_json(indent=2),
         "cache_control": {"type": "ephemeral"}},
    ]
    response = client.messages.create(
        model=config.MODEL_CRITIC,
        max_tokens=4000,
        system=system,
        tools=[{"type": config.WEB_SEARCH_TOOL_TYPE, "name": "web_search",
                "max_uses": config.MAX_SEARCHES_CRITIC}],
        messages=[{"role": "user",
                   "content": "# CAPITOLO DA VERIFICARE\n\n"
                              + chapter_path.read_text(encoding="utf-8")}],
    )
    text = "".join(b.text for b in response.content if getattr(b, "type", "") == "text")
    out = chapter_path.with_suffix(".critic.json")
    out.write_text(text, encoding="utf-8")
    print(f"[critic] → {out.name}")
    return out


def main() -> None:
    fixture = Path(sys.argv[1])
    data = json.loads(fixture.read_text(encoding="utf-8"))
    brief = Brief(**data["brief"])
    assignment = ChapterAssignment(**data["assignment"])
    out_dir = Path("output") / brief.brief_id

    chapter = run_chapter(brief, assignment, out_dir)
    if "--critic" in sys.argv:
        run_critic(brief, chapter)


if __name__ == "__main__":
    main()
