"""Libreria asset — CATTURA fin dalla v0, riuso dalla v1.

Regola decisa: l'asset si riusa solo dove aumenta il valore per il cliente.
Evergreen → asset con rifinitura cumulativa. Deperibile/personale → sempre fresco.
La v0 si limita a salvare ogni sezione prodotta con i suoi metadati; la logica
retrieve→freshness-check→personalizza arriva quando ci sono abbastanza asset.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path

from schema.brief import Brief, ChapterAssignment
from src import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY,
    destinazione TEXT NOT NULL,          -- es. "Lisbona"
    tipo TEXT NOT NULL,                  -- storia_luogo | quartiere | esperienza | box
    titolo TEXT NOT NULL,
    deperibilita TEXT NOT NULL,          -- evergreen | stagionale | volatile
    testo TEXT,                          -- v0: può restare NULL (si salva il raw META)
    meta_raw TEXT,                       -- blocco META grezzo da cui è nato
    fonte_capitolo TEXT,                 -- file capitolo di origine
    brief_id TEXT,
    created_at TEXT NOT NULL,
    last_verified_at TEXT,
    reuse_count INTEGER DEFAULT 0,
    refinement_count INTEGER DEFAULT 0,
    quality_score REAL DEFAULT 0.0       -- alimentato da rifiniture/segnalazioni
);
CREATE INDEX IF NOT EXISTS idx_assets_dest ON assets(destinazione, tipo);
"""


def _db() -> sqlite3.Connection:
    path = Path(config.ASSETS_DB)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.executescript(SCHEMA)
    return conn


def capture_assets(brief: Brief, assignment: ChapterAssignment, meta: dict) -> None:
    """v0: salva il blocco META grezzo per destinazione. Il parsing fine arriva in v1;
    l'importante è NON buttare via niente da subito."""
    dest = assignment.tappa.luogo if assignment.tappa else "generale"
    now = datetime.now(timezone.utc).isoformat()
    with _db() as conn:
        conn.execute(
            """INSERT INTO assets
               (destinazione, tipo, titolo, deperibilita, meta_raw,
                fonte_capitolo, brief_id, created_at, last_verified_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (dest, "capitolo_meta", assignment.titolo_provvisorio, "misto",
             meta.get("raw", ""), f"cap_{assignment.numero:02d}.md",
             brief.brief_id, now, now),
        )
