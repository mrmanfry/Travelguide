"""Chapter runner — genera UN capitolo via API Anthropic con web search e prompt caching.

Design v0:
- una chiamata per capitolo, mai una conversazione lunga (costo ~lineare, non quadratico)
- system = [style_guide (cache), chapter_system (cache), brief (cache per-guida)]
  → il prefisso in cache deve essere IDENTICO byte-per-byte tra i capitoli della stessa guida
- il messaggio user contiene solo l'assignment del capitolo
- output salvato subito su disco (idempotenza: un crash al cap. 12 riparte dal 12)

NB: verificare tipo/versione del web search tool e parametri correnti sui docs ufficiali
(https://platform.claude.com/docs) prima del primo run: le stringhe versionate cambiano.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

import anthropic

from schema.brief import Brief, ChapterAssignment
from src import config
from src.assets import capture_assets

PROMPTS = Path(__file__).resolve().parent.parent / "prompts"


def _load(name: str) -> str:
    return (PROMPTS / name).read_text(encoding="utf-8")


def build_system_blocks(brief: Brief) -> list[dict]:
    """Blocchi system con cache breakpoints.

    style_guide + chapter_system sono identici per TUTTE le guide → cache stabile.
    Il brief è identico per tutti i capitoli della STESSA guida → secondo breakpoint.
    """
    style = _load("style_guide.md")
    chapter = _load("chapter_system.md").replace("{{LINGUA}}", brief.lingua_guida)
    brief_block = (
        "# BRIEF DEL VIAGGIO (contesto fisso della guida)\n\n"
        + brief.model_dump_json(indent=2)
    )
    return [
        {"type": "text", "text": style + "\n\n---\n\n" + chapter,
         "cache_control": {"type": "ephemeral"}},
        {"type": "text", "text": brief_block,
         "cache_control": {"type": "ephemeral"}},
    ]


def build_user_message(assignment: ChapterAssignment) -> str:
    return (
        "# ASSIGNMENT DI QUESTO CAPITOLO\n\n"
        + assignment.model_dump_json(indent=2)
        + "\n\nProcedi: ricerca, poi scrivi il capitolo completo con il blocco META finale."
    )


def parse_meta(chapter_md: str) -> tuple[str, dict | None]:
    """Separa il testo del capitolo dal blocco META (best-effort)."""
    m = re.search(r"<!--META\s*(.*?)\s*META-->", chapter_md, re.DOTALL)
    if not m:
        return chapter_md, None
    body = chapter_md[: m.start()].rstrip()
    return body, {"raw": m.group(1)}


def run_chapter(brief: Brief, assignment: ChapterAssignment, out_dir: Path) -> Path:
    client = anthropic.Anthropic()  # ANTHROPIC_API_KEY dall'ambiente
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"cap_{assignment.numero:02d}.md"
    if out_path.exists():
        print(f"[skip] {out_path.name} esiste già (idempotenza)")
        return out_path

    response = client.messages.create(
        model=config.MODEL_GENERATION,
        max_tokens=config.MAX_TOKENS_CHAPTER,
        system=build_system_blocks(brief),
        tools=[{
            "type": config.WEB_SEARCH_TOOL_TYPE,
            "name": "web_search",
            "max_uses": config.MAX_SEARCHES_PER_CHAPTER,
        }],
        messages=[{"role": "user", "content": build_user_message(assignment)}],
    )

    text = "".join(b.text for b in response.content if getattr(b, "type", "") == "text")
    body, meta = parse_meta(text)

    out_path.write_text(text, encoding="utf-8")
    (out_dir / f"cap_{assignment.numero:02d}.usage.json").write_text(
        json.dumps(response.usage.model_dump() if hasattr(response.usage, "model_dump")
                   else dict(response.usage), indent=2, default=str),
        encoding="utf-8",
    )
    if meta:
        capture_assets(brief, assignment, meta)

    print(f"[ok] {out_path.name} — {len(body.split())} parole")
    return out_path
