"""Configurazione engine v0. Ogni numero qui è una leva di costo o qualità."""

# Modelli — verificare gli id correnti su https://platform.claude.com/docs
MODEL_GENERATION = "claude-sonnet-4-6"   # qualità della prosa = qualità del prodotto
MODEL_CRITIC = "claude-sonnet-4-6"       # v1: valutare Haiku per i check meccanici

# Web search tool — verificare la stringa versione corrente sui docs prima del primo run
WEB_SEARCH_TOOL_TYPE = "web_search_20250305"

MAX_TOKENS_CHAPTER = 16000
MAX_SEARCHES_PER_CHAPTER = 6
MAX_SEARCHES_CRITIC = 8

# Budget parole per tipo capitolo (moltiplicati poi per densità tappa)
PAROLE_PER_TAPPA_BASE = 1800
PAROLE_PER_NOTTE = 900
PAROLE_CAP_MAX = 8000

# Percorsi
ASSETS_DB = "output/assets.sqlite"
