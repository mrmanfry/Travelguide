# CAPITOLO DI TEST — MOTORE DI GENERAZIONE

**Brief fixture:** Giulia e Marco, coppia ~30 anni, anniversario. Venerdì 18 – lunedì 21 settembre 2026, 3 notti, hotel Memmo Alfama. Passioni: cibo e fotografia. Ritmo lento, budget medio-alto. Guida ipotetica: cap. 1 breve introduzione al Portogallo (già scritto, nella finzione), cap. 2 questa tappa. Budget parole: ~2.800.

---

# CAPITOLO 2

# LISBONA / ALFAMA
### La città che la fine del mondo ha risparmiato a metà

***

## I. Un arrivo

C'è una luce, a Lisbona, che non assomiglia a quella di nessun'altra capitale europea, e la prima cosa da fare — venerdì sera, quando arriverete — è non sprecarla. È una luce obliqua e marittima, che rimbalza sul Tejo largo come un mare e risale i colli sbiancando la calçada, il selciato di pietre bianche e nere che qui non è pavimentazione ma calligrafia. I fotografi la chiamano semplicemente *a luz*, la luce, come se l'articolo determinativo bastasse a distinguerla da tutte le altre. Avrete tre giorni per impararla: cambia ora per ora, e settembre — quando il caldo si è arreso ma il sole è ancora alto sull'acqua — è considerato da molti lisboeti il mese in cui la città somiglia di più a se stessa.

Il vostro albergo è nel posto giusto per cominciare. Il Memmo Alfama sta infilato in una traversa minuscola, la Travessa das Merceeiras, a due passi dalla cattedrale: un edificio di fine Ottocento — prima una panetteria, poi una rimessa — trasformato nel primo hotel del quartiere vecchio. La sua terrazza con la piscina guarda i tetti rossi di Alfama che scendono a cascata verso il fiume, ed è lì che vi conviene salire appena posate le valigie, con un bicchiere di vinho verde del wine bar in mano. Quello che vedrete dall'alto è un miracolo di sopravvivenza, e capirlo cambierà il modo in cui camminerete nei tre giorni successivi.

## II. Il giorno in cui finì il mondo

Perché Lisbona, quella vera, è morta una mattina precisa: il 1° novembre 1755, alle nove e quaranta. Era Ognissanti, le chiese erano piene e illuminate da migliaia di candele. Il terremoto — si stima oggi tra 8,5 e 9 gradi di magnitudo, uno dei più violenti mai registrati in Europa — durò minuti che ai sopravvissuti parvero ore. Poi il mare si ritirò dal porto, scoprendo relitti e fondali, e la folla scese sulla riva a guardare la meraviglia: mezz'ora dopo lo tsunami la travolse. Quello che il mare risparmiò lo presero le fiamme delle candele di Ognissanti, che bruciarono la città per giorni. Morirono decine di migliaia di persone; l'Europa illuminista ne rimase segnata al punto che Voltaire ci costruì sopra il *Candide*, chiedendosi come si potesse ancora sostenere che questo fosse "il migliore dei mondi possibili".

Da quella mattina esistono due Lisbone, e voi dormirete esattamente sul confine. Sotto di voi, verso ovest, la Baixa: la città nuova che il marchese di Pombal fece ricostruire in pochi anni su una griglia razionale, con edifici antisismici a gabbia di legno — la *gaiola pombalina* — collaudati, si racconta, facendo marciare plotoni di soldati sui prototipi per simulare le scosse. È una delle prime città pianificate d'Europa, geometrica e teatrale. E poi c'è Alfama, il quartiere in cui alloggiate: costruito su roccia più solida, il labirinto moresco resse dove il resto crollò. Il nome viene dall'arabo *al-hamma*, le fonti calde; i vicoli che percorrerete per salire in albergo seguono ancora il tracciato di mille anni fa. Alfama non è "pittoresca": è l'unico frammento superstite di una capitale scomparsa, abitato senza interruzione da prima che Lisbona fosse portoghese. I panni stesi tra le finestre e le sardine sulla brace non sono scenografia — sono la continuazione di una vita che il terremoto non è riuscito a interrompere.

> **SLANG DEL GIORNO — "Saudade", la parola che non si traduce**
>
> I portoghesi sostengono, con un certo orgoglio, che *saudade* (si pronuncia sa-u-DÀ-de) non esista in nessun'altra lingua. È la nostalgia di qualcosa che forse non è mai accaduto: la mancanza di ciò che si è perduto, ma anche di ciò che non si è mai avuto. È il sentimento fondativo del fado e, secondo molti, del carattere nazionale — l'eredità di un piccolo paese che per secoli ha guardato partire le sue navi senza sapere se sarebbero tornate. Non dovete usarla: dovete riconoscerla. La sentirete nella voce delle fadiste, sabato sera. Un'altra parola utile e più allegra: *miradouro* (belvedere), che sarà la vostra unità di misura della città.

## III. Sabato: la mattina del fotografo

Alfama all'alba è un quartiere diverso da Alfama alle undici, e la differenza non è di grado ma di natura. Dalle sette e mezza — a metà settembre il sole sorge poco dopo le sette — avete circa due ore in cui i vicoli sono vostri: la luce radente accende gli azulejos, i gatti presidiano i gradini, i primi vecchi escono a comprare il pane. Alle dieci arrivano i gruppi e i tuk-tuk, e la finestra si chiude. Per chi fotografa, la regola di Lisbona è brutale e semplice: la città bella esiste prima delle nove e mezza.

L'itinerario del sabato mattina si disegna da solo, ed è in discesa. Salite (a piedi o con un taxi da tre euro) fino alla Graça, il quartiere sopra il vostro: il Miradouro da Sossego della Senhora do Monte è il punto più alto della città vecchia, con il castello, i tetti e il fiume in un'unica inquadratura. Da lì scendete verso il Largo da Graça e la Rua da Graça: è qui — non nei punti famosi di Alfama — che si fotografa il tram 28 senza folla, perché il quartiere è residenziale e il tram passa ogni dieci-quindici minuti tra palazzi scrostati e panni stesi, senza un turista nell'inquadratura. Poi giù verso Portas do Sol: il punto classico è la curva tra il Largo das Portas do Sol e Santa Luzia, dove il tram svolta con la chiesa di São Vicente sullo sfondo. A quell'ora ci sarete quasi soli; alle undici è una fila di treppiedi.

E qui serve dire una cosa onesta sul tram 28, perché nessuna guida ve la dirà con questa chiarezza.

> **ATTENZIONE — Il tram 28 si fotografa, non si prende**
>
> Il 28 è diventato vittima di se stesso: dopo le 9:30 la coda al capolinea di Martim Moniz può superare le due ore, per poi viaggiare in piedi, schiacciati, in quello che è anche il percorso preferito dai borseggiatori della città. In più il percorso risulta accorciato da cantieri stradali il cui completamento era previsto per inizio 2026: verificate lo stato sul sito di Carris prima di contarci. Se lo volete vivere davvero, prendetelo alla prima corsa del mattino (prima delle 8) oppure salite sulla linea 12, che usa le stesse vetture Remodelado degli anni Trenta su un anello più corto e quasi ignorato dai turisti. Ma il modo migliore di godervi il 28 resta quello del fotografo: fermi al posto giusto, ad aspettare che il giallo entri nell'inquadratura.

La fortuna del calendario vi regala poi il pezzo migliore del sabato: la **Feira da Ladra**, il mercato delle pulci più antico della città — le radici documentate risalgono al Duecento — si tiene solo il martedì e il sabato, dalle 9 alle 18, al Campo de Santa Clara, dieci minuti a piedi dal vostro percorso, tra il Pantheon Nazionale e São Vicente de Fora. Il nome, "fiera della ladra", viene dalla fama antica di mercato di refurtiva; oggi è un teatro all'aperto dove i lisboeti vendono le cantine di famiglia: azulejos spaiati, macchine fotografiche sovietiche, spartiti di fado ingialliti, divise coloniali. Per due che viaggiano con la macchina fotografica è un giacimento doppio — di soggetti e di souvenir veri. Portate contanti e pazienza; il pezzo giusto salta fuori al terzo giro, non al primo.

## IV. A tavola: le due cucine di Lisbona

Lisbona si mangia su due registri, e un weekend ben costruito li tocca entrambi. Il primo registro è la *tasca*: la trattoria di quartiere con il menù scritto sulla lavagna, i piatti che escono dalla cucina come telegrammi e il conto che sembra un errore. Il secondo è la nuova alta cucina portoghese che nell'ultimo decennio ha trasformato la città in una capitale gastronomica — con sedici ristoranti stellati, il numero più alto della sua storia.

Per il primo registro avete l'imbarazzo della scelta a distanza di passeggiata. **O Velho Eurico**, vicino al castello, è la tasca nella sua forma più pura e più rumorosa: menù sulla lavagna, porzioni piccole da condividere, il bacalhau à Brás che vola tra i tavoli e il leite-creme della casa che finisce presto. Non prendono prenotazioni con larghezza: presentatevi all'apertura o mettete il nome in lista e fate un giro. Per il rito delle *cervejarias* — gamberi al sale, granchio, pane col burro e birra gelata — l'istituzione è **Cervejaria Ramiro**, in fondo alla Avenida Almirante Reis: sappiate che ormai la prenotazione richiede un deposito, segno dei tempi ma anche garanzia che il tavolo ci sia.

La cena dell'anniversario, sabato sera, merita il secondo registro. Le due tavole con due stelle Michelin sono **Belcanto** di José Avillez, al Chiado, e **Alma** di Henrique Sá Pessoa: menù degustazione da circa 235 euro a testa (vini esclusi), prenotazione da fare adesso, non a Lisbona. Sono esperienze diverse — Belcanto più teatrale, Alma più intimo — ma entrambe fanno la stessa operazione: prendere la memoria gastronomica portoghese, dal baccalà alla cataplana, e restituirla irriconoscibile e commovente insieme. Un'avvertenza da verifica fresca: se nelle vostre ricerche online incontrate **Arkhe**, il vegetariano stellato di cui molte liste parlano ancora, sappiate che ha chiuso definitivamente a fine 2025; e **Feitoria**, a Belém, risulta temporaneamente chiuso. Le liste invecchiano più in fretta delle città.

> **A TAVOLA — Il pastel de nata, e dove mangiarlo davvero**
>
> Il pasticcino nazionale nacque per economia domestica: i monaci dei Jerónimos usavano gli albumi per inamidare le tonache, e con i tuorli avanzati inventarono la crema. Il pellegrinaggio classico è Pastéis de Belém, che custodisce la ricetta "originale" dal 1837 — ma sappiate che la sede storica è in ristrutturazione nel 2026 e si compra nella nuova sala accanto. Il segreto dei lisboeti, però, è **Manteigaria** (la sede di Rua do Loreto 2, aperta fino a mezzanotte): sfoglia più croccante, crema meno dolce, e una campanella che suona a ogni infornata. Regola d'oro in entrambi i casi: si mangia caldo, in piedi, con cannella e un espresso — la *bica*. Mai comprarne "una scatola da portare a casa": a casa non ci arrivano.

> **SMART LUXURY — Il fado vero costa una cena, non un biglietto**
>
> Le grandi *casas de fado* di Alfama propongono cena e spettacolo a prezzi da teatro dell'opera, con qualità musicale spesso vera ma atmosfera da tour operator. L'alternativa intelligente è il *fado vadio*, il fado "randagio" cantato da dilettanti — vicini di casa, signore in pensione, il cuoco stesso — nelle tascas del quartiere: si paga la cena, non l'artista, e capita la serata in cui una voce anonima vale più di un disco. Chiedete al concierge del Memmo quale tasca ha fado la vostra sera (il calendario è fluido e va verificato sul posto): è esattamente il tipo di domanda per cui l'hotel offre ai suoi ospiti anche passeggiate guidate gratuite di Alfama — approfittatene la prima mattina, vi metterà il quartiere in tasca.

## V. Domenica: il problema del giorno del Signore

La domenica a Lisbona ha una regola non scritta che coglie di sorpresa quasi tutti: le tascas chiudono. Alfama la domenica sera è un quartiere a saracinesche abbassate, e trovarsi alle venti con la fame e senza piano è il modo classico di rovinare l'ultima sera. La soluzione è girare la giornata verso ovest: **Belém**, lungo il fiume, dove i luoghi vivono di domenica invece di morirne.

Belém è il quartiere da cui il Portogallo partì per il mondo, e tiene insieme in un chilometro la versione imperiale e quella contemporanea del paese. Il Mosteiro dos Jerónimos, pagato con la "tassa del pepe" sulle spezie delle Indie, è il capolavoro del manuelino — quello stile in cui la pietra si fa corda, nodo, alga marina, come se la cattedrale fosse stata scolpita da marinai. La Torre di Belém poco più in là era il faro-fortezza che salutava le caravelle. E sul fiume, il MAAT — il museo di arte, architettura e tecnologia con il tetto ondulato su cui si cammina — vi dà l'inquadratura moderna: il ponte 25 de Abril rosso sopra il Tejo, che al tramonto della domenica, con la luce che viene da dietro il Cristo Rei, è una delle fotografie della città. Andate ai Jerónimos all'apertura per evitare la coda, dedicate il pomeriggio al fiume, e per cena restate in zona o rientrate verso il Cais do Sodré e il Chiado, dove la domenica sera si mangia senza patemi.

## VI. La pratica dei tre giorni

**Muoversi.** Lisbona centro si fa a piedi, ma "a piedi" qui significa in salita: mettete in conto dislivelli da sentiero e scarpe con suola vera — la calçada bagnata è bella e scivolosa come il marmo. Per tutto il resto, caricate una carta trasporti (la Viva Viagem, o il biglietto 24 ore se prevedete più corse): vale su tram, elevadores, metro, e vi fa saltare le code alle biglietterie dei mezzi storici. I taxi e le app costano poco; la corsa media in centro sta sotto i dieci euro.

**Il ritmo giusto.** Con tre notti la tentazione è correre. Resistete: Lisbona premia chi la usa come i lisboeti, a ondate — la mattina presto per la città e le fotografie, il pranzo lungo, il tardo pomeriggio ai miradouri con una birra del chiosco, la sera a tavola. Sintra, che tutti vi diranno di non perdere, con tre notti è un errore: vi mangerebbe un giorno intero dei tre, e mezza giornata di corsa in un posto pensato per la lentezza. Tenetela come primo motivo per tornare.

**Attenzioni.** L'unico vero fastidio della città sono i borseggiatori sui mezzi affollati (il 28 su tutti) e l'offerta insistente di "hashish" sussurrata in Baixa — che è quasi sempre finto, e va ignorata con un sorriso. Per il resto, Lisbona è una capitale in cui camminare di notte mette allegria, non ansia.

Lunedì mattina, prima del volo, salite un'ultima volta sulla terrazza dell'albergo con il caffè. Guardate i tetti che avete imparato a leggere: la città nuova di Pombal a destra, il labirinto sopravvissuto sotto di voi, il fiume che finge di essere mare davanti. Tre giorni prima era un panorama. Adesso sapete cosa state guardando — ed è questa, alla fine, la sola differenza che conta tra passare da un posto e esserci stati.

---
*Fine capitolo di test. Fatti verificati via ricerca il 21/07/2026: stato Feira da Ladra (mar/sab 9-18), chiusura definitiva Arkhe (nov 2025), chiusura temporanea Feitoria, ristrutturazione sede storica Pastéis de Belém, deposito richiesto da Ramiro, cantieri percorso tram 28, stelle e prezzi Belcanto/Alma, operatività e servizi Memmo Alfama.*
