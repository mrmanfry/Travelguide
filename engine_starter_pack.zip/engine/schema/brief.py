"""Schema del brief — IL contratto dati tra intake, engine e piattaforma.

Qualunque componente (piattaforma web, engine, verifica) parla solo questo formato.
Modificare qui = modificare il contratto: farlo con giudizio e versionare.
"""
from __future__ import annotations

from datetime import date
from typing import Literal, Optional

from pydantic import BaseModel, Field


class Tappa(BaseModel):
    ordine: int
    luogo: str                      # nome visualizzato, es. "Lisbona"
    place_id: Optional[str] = None  # id autocomplete (Google Places o equivalente)
    notti: int
    hotel: Optional[str] = None     # dal file logistica, se presente
    note_logistica: Optional[str] = None  # es. "arrivo ven sera ore 22, TAP da FCO"


class DateViaggio(BaseModel):
    inizio: Optional[date] = None
    fine: Optional[date] = None
    flessibili: bool = False
    mese: Optional[str] = None      # usato se le date esatte mancano


class Viaggiatori(BaseModel):
    adulti: int = 2
    bambini_eta: list[int] = Field(default_factory=list)
    occasione: Literal[
        "luna_di_miele", "coppia", "anniversario", "famiglia", "amici", "solo", "altro"
    ] = "coppia"


class Stile(BaseModel):
    avventura_relax: int = Field(3, ge=1, le=5)  # 1=relax puro, 5=avventura
    ritmo: int = Field(3, ge=1, le=5)            # 1=lento, 5=pieno
    budget_fascia: Literal["contenuto", "medio", "medio_alto", "alto"] = "medio"


class Passione(BaseModel):
    tema: str                       # es. "cibo"
    dettaglio: Optional[str] = None # es. "mercati e una cena stellata, no cucina fusion"


class Oro(BaseModel):
    """L'output del colloquio AI: la parte che rende la guida LORO."""
    da_non_perdere: list[str] = Field(default_factory=list)
    da_evitare: list[str] = Field(default_factory=list)
    contesto_emotivo: Optional[str] = None  # perché questo viaggio, cosa deve essere
    note_libere: Optional[str] = None


class Brief(BaseModel):
    brief_id: str
    lingua_guida: str = "it"
    tappe: list[Tappa]
    date: DateViaggio
    viaggiatori: Viaggiatori
    stile: Stile
    passioni: list[Passione] = Field(default_factory=list)
    oro: Oro = Field(default_factory=Oro)

    @property
    def giorni(self) -> int:
        if self.date.inizio and self.date.fine:
            return (self.date.fine - self.date.inizio).days + 1
        return sum(t.notti for t in self.tappe) + 1


class ChapterAssignment(BaseModel):
    """Cosa deve produrre una singola chiamata di generazione."""
    numero: int
    titolo_provvisorio: str
    tappa: Optional[Tappa] = None          # None per capitoli introduttivi/apparati
    tipo: Literal["introduzione", "tappa", "apparati"] = "tappa"
    budget_parole: int
    outline_guida: list[str]               # titoli di tutti i capitoli della guida
    riassunti_precedenti: list[str] = Field(default_factory=list)  # 2 righe per cap. già scritto
